// modules/excel-exporter.js

/**
 * Асинхронно отправляет код скрейпера на ваш сервер.
 */ 
async function sendScraperToApi(hostname, fingerprint) {
    try {
        const storageKey = fingerprint;
        if (!storageKey) return;

        const data = await chrome.storage.local.get([storageKey]);
        const scraperCode = data[storageKey];

        if (!scraperCode) return;

        // --- ИСПРАВЛЕНИЕ "Array" ---
        // Превращаем объект/массив конфигурации в строку перед отправкой
        let codeToSend = scraperCode;
        if (typeof scraperCode === 'object' && scraperCode !== null) {
            codeToSend = JSON.stringify(scraperCode);
        }
        // ---------------------------

        fetch(self.API_ENDPOINT_SAVE_SCRAPER, {  
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                hostname: hostname,
                scraper_code_exp: codeToSend,
                layout_fingerprint: fingerprint 
            })
        }).catch(err => console.warn("Save scraper API error (non-critical):", err));

    } catch (error) {
        console.error('Error in sendScraperToApi:', error);
    }
}

/**
 * Форматирует данные.
 */
function formatProductsForExcel(products) {
    return products.map(p => {
        // --- Обработка сложных полей ---
        let imagesString = "";
        const imgArray = p.image || p.imageUrls; 
        if (Array.isArray(imgArray) && imgArray.length > 0) {
            imagesString = imgArray.join(' ; ');
        } else if (typeof imgArray === 'string') {
            imagesString = imgArray;
        }

        let specsString = "";
        if (Array.isArray(p.characteristics) && p.characteristics.length > 0) {
            specsString = p.characteristics
                .map(spec => `${spec.key || ''}: ${spec.value || ''}`)
                .filter(s => s.trim() !== ":")
                .join(' | ');
        }

        // --- Базовый объект (фиксированные поля) ---
        const formattedItem = {
            "Product Name": p.name || "",
            "Price": p.price || "",
            "Sale Price": p.promotionalPrice || "",
            "Description": p.description || "",
            "Images": imagesString,
            "Characteristics": specsString,
            "URL": p.url || "",
            "SKU": p.sku || "",
            "Brand": p.brand || "",  
            "Category": p.category || "",
            "Rating": p.rating || "", 
            "Availability": p.availability || ""
        };

        const handledKeys = [
            'name', 'price', 'promotionalPrice', 'description', 
            'image', 'imageUrls', 'characteristics', 'url', 
            'sku', 'brand', 'category', 'rating', 'availability'
        ];

        // --- Динамические поля ---
        Object.keys(p).forEach(key => {
            if (!handledKeys.includes(key)) {
                let value = p[key];
                if (Array.isArray(value)) {
                    value = value.join(', ');
                } else if (typeof value === 'object' && value !== null) {
                    value = JSON.stringify(value);
                }
                const headerName = key.charAt(0).toUpperCase() + key.slice(1);
                formattedItem[headerName] = value || "";
            }
        });

        return formattedItem;
    });
}

async function handleExcelExport(message, sender, sendResponse) {
    try {
        const url = new URL(message.url);
        const hostname = url.hostname.replace(/^www\./, '');
        const fingerprint = message.fingerprint;

        const session = await getSession(hostname);

        if (!session || !session.products || session.products.length === 0) {
            chrome.runtime.sendMessage({ action: "parsingError", error: "Нет данных для экспорта." });
            return;
        }

        // --- Проверка лимита ---
        const storageData = await chrome.storage.local.get(['isPremiumUser']);
        const isPremium = storageData.isPremiumUser === true;
        const FREE_LIMIT = 100;

        let productsToExport = session.products;

        if (!isPremium && productsToExport.length > FREE_LIMIT) {
            productsToExport = productsToExport.slice(0, FREE_LIMIT);
             chrome.runtime.sendMessage({ action: "parsingError", error: "Free Tier: Экспортировано только 100 товаров." });
        }
        
        sendScraperToApi(hostname, fingerprint);

        // --- Форматирование данных ---
        const formattedProducts = formatProductsForExcel(productsToExport); 

        // --- ГАРАНТИЯ ПОРЯДКА КОЛОНОК ---
        
        // 1. Задаем наш желаемый жесткий порядок
        const fixedHeaders = [
            "Product Name", 
            "Price", 
            "Sale Price", 
            "Description", 
            "Images", 
            "Characteristics", 
            "URL", 
            "SKU", 
            "Brand", 
            "Category", 
            "Rating", 
            "Availability"
        ];

        // 2. Ищем все дополнительные (динамические) заголовки, которые есть в данных
        const allDynamicHeaders = new Set();
        formattedProducts.forEach(item => {
            Object.keys(item).forEach(key => {
                if (!fixedHeaders.includes(key)) {
                    allDynamicHeaders.add(key);
                }
            });
        });

        // 3. Собираем итоговый массив заголовков: Фиксированные + Динамические
        const finalHeaders = [...fixedHeaders, ...Array.from(allDynamicHeaders)];

        // --- Генерация Excel ---
        const filename = `${hostname}_products_${new Date().toISOString().split('T')[0]}.xlsx`;
        
        // ВАЖНО: Передаем { header: finalHeaders } вторым аргументом!
        // Это заставит библиотеку использовать именно этот порядок колонок.
        const ws = XLSX.utils.json_to_sheet(formattedProducts, { header: finalHeaders });
        
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Products");
        
        if (!isPremium) {
             XLSX.utils.sheet_add_aoa(ws, [["Upgrade to Premium to export unlimited items"]], {origin: -1});
        }

        const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/octet-stream' });

        const reader = new FileReader();
        reader.onload = function() {
            chrome.downloads.download({
                url: reader.result,
                filename: filename,
                saveAs: true
            }).catch(err => {
                console.error("Download failed:", err);
                chrome.runtime.sendMessage({
                    action: "parsingError",
                    error: "Ошибка при сохранении файла."
                });
            });
        };
        reader.readAsDataURL(blob);

    } catch (error) {
        console.error("Export error:", error);
        chrome.runtime.sendMessage({
            action: "parsingError",
            error: "Критическая ошибка экспорта: " + error.message
        });
    }
} 

self.handleExcelExport = handleExcelExport;