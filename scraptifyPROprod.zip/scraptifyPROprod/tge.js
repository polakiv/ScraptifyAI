async function scrapeProducts() {
    let isCancelled = false;
    const cancelListener = () => {
        console.log("Stop signal received.");
        isCancelled = true;
    };
    window.addEventListener('stop-scraping', cancelListener, { once: true });

    const delay = (ms) => new Promise(res => setTimeout(res, ms));
    const products = [];

    // --- РЕЖИМ МАКСИМАЛЬНОЙ НАДЕЖНОСТИ ---
    const BATCH_SIZE = 1; // Сохраняем после КАЖДОГО товара
    const MAX_EMPTY_CHECKS = 15; // Больше попыток поиска, так как скроллим аккуратно

    // Функция конвертации картинки (остается такой же)
    const blobToBase64 = async (blobUrl) => {
        try {
            const response = await fetch(blobUrl);
            const blob = await response.blob();
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            });
        } catch (err) {
            console.error("Failed to convert image:", err);
            return null;
        }
    };

    // Агрессивная очистка памяти DOM
    const optimizeMemory = (element) => {
        // Жестко фиксируем высоту, чтобы лента не схлопнулась
        const rect = element.getBoundingClientRect();
        element.style.height = `${rect.height}px`;
        element.style.minHeight = `${rect.height}px`;
        element.style.overflow = 'hidden'; // Скрываем содержимое
        
        // Полностью удаляем HTML внутри элемента
        element.innerHTML = '<div style="background:#e0ffe0; color:green; font-size:10px; padding:2px; text-align:center;">✅ SAVED & CLEARED</div>';
        
        // Помечаем, чтобы парсер игнорировал этот элемент при следующем запуске
        element.setAttribute('data-scraped', 'true');
        element.classList.add('scraped-done');
    };

    try {
        // console.log("Single-item mode active..."); // Можно закомментировать, чтобы не спамить в консоль
        const category = document.querySelector('.chat-info .peer-title')?.textContent?.trim() || "Chat";
        const scrollContainer = document.querySelector('.scrollable') || window;
        
        let consecutiveEmptyFinds = 0;

        // Цикл по сути выполнится 1 раз, если товар найден, или будет крутиться пока ищет
        while (!isCancelled) {
            
            // Если уже нашли 1 товар — СТОП, отдаем его базе данных
            if (products.length >= BATCH_SIZE) {
                break; 
            }

            // Ищем первый попавшийся НЕ обработанный элемент
            const itemElement = document.querySelector('div.bubble:not(.is-sponsored):not(.service):not([data-scraped="true"])');

            if (!itemElement) {
                consecutiveEmptyFinds++;
                // console.log(`Searching... ${consecutiveEmptyFinds}`);

                // Логика умного скролла
                if (scrollContainer.scrollBy) {
                    // Скроллим вверх (обычно там старые сообщения)
                    scrollContainer.scrollBy(0, -350); 
                } else {
                    window.scrollBy(0, -350);
                }

                if (consecutiveEmptyFinds >= MAX_EMPTY_CHECKS) {
                    console.log("No more items found.");
                    // Возвращаем null в nextPageSelector, чтобы полностью остановить парсинг
                    return { products, nextPageSelector: null };
                }
                
                await delay(1000); // Ждем подгрузки
                continue;
            }

            // Сбрасываем счетчик ошибок, так как нашли элемент
            consecutiveEmptyFinds = 0;

            // Скроллим к элементу
            itemElement.scrollIntoView({ behavior: 'auto', block: 'center' });
            await delay(500); // Чуть ждем загрузку медиа

            try {
                // --- СБОР ДАННЫХ ---
                const textContainer = itemElement.querySelector('.translatable-message') || 
                                      itemElement.querySelector('.message') || 
                                      itemElement.querySelector('.webpage-title');
                
                let description = textContainer ? textContainer.innerText.trim() : "";
                
                // Ищем картинки
                const imageElements = itemElement.querySelectorAll('img.media-photo, video.media-video, img[src^="blob:"]');
                const blobUrls = Array.from(imageElements).map(img => img.src).filter(Boolean);
                
                let base64Image = null;
                if (blobUrls.length > 0) {
                     base64Image = await blobToBase64(blobUrls[0]); 
                }

                const linkElement = itemElement.querySelector('a[href]:not(.mention)');
                const url = linkElement ? linkElement.href : null;

                // --- СОХРАНЕНИЕ ---
                if (base64Image || description.length > 1) {
                    products.push({
                        name: description.slice(0, 50) || "Media Content",
                        price: null,
                        url: url || window.location.href,
                        imageUrls: blobUrls, 
                        fullImageStore: base64Image, // Тяжелая картинка
                        description: description,
                        category: category
                    });
                }

                // --- ЧИСТКА ---
                // Сразу же удаляем этот элемент из DOM и помечаем его
                optimizeMemory(itemElement);

            } catch (innerError) {
                console.error("Error processing item:", innerError);
                itemElement.setAttribute('data-scraped', 'error'); // Помечаем как ошибку, чтобы пропустить
            }
        }

        // Возвращаем текущий URL как "следующую страницу".
        // Расширение увидит, что URL тот же самый, НЕ будет перезагружать вкладку,
        // но запустит этот скрипт заново.
        // Так как мы пометили элементы атрибутом [data-scraped="true"], 
        // следующий запуск скрипта найдет следующий по очереди элемент.
        return { 
            products, 
            nextPageSelector: window.location.href 
        };

    } catch (e) {
        console.error("Global error:", e);
        return { products, nextPageSelector: null };
    } finally {
        window.removeEventListener('stop-scraping', cancelListener);
    }
}