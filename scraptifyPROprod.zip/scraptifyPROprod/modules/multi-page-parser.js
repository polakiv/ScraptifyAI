// multi-page-parser.js
// modules/multi-page-parser.js — Отдел Генерации.
// Многостраничный парсинг с остановкой и возобновлением
console.log("🟢 МОДУЛЬ: multi-page-parser.js ЗАГРУЖЕН");

// --- НОВАЯ ФУНКЦИЯ: Внедрение панели статуса на страницу ---
function injectOverlayStatus(statusText, progressText) {
    let container = document.getElementById('scraptify-overlay-panel');
    
    // Если контейнера нет, создаем его
    if (!container) {
        container = document.createElement('div');
        container.id = 'scraptify-overlay-panel';
        container.style.cssText = `
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		background: rgba(18, 18, 18, 0.95);
		border-top: 3px solid #4CAF50;
		color: #fff;
		z-index: 2147483647; /* Максимальный z-index */
		padding: 10px 20px;
		box-sizing: border-box;
		font-family: sans-serif;
		box-shadow: 0 -4px 10px rgba(0,0,0,0.5);
		display: flex;
		flex-direction: column;
		gap: 8px;
        `;
		
        container.innerHTML = `
		<div style="border: 1px solid #4CAF50; background: #000; padding: 4px; border-radius: 4px;">
		<marquee id="scraptify-injected-marquee" scrollamount="12" style="color: #4CAF50; font-weight: bold; font-size: 14px; text-transform: uppercase;">
		Initializing...
		</marquee>
		</div>
		<p id="scraptify-injected-progress" style="margin: 0; text-align: center; font-size: 14px; font-weight: bold; color: #fff;">
		Waiting to start...
		</p>
        `;
        document.body.appendChild(container);
	}
	
    // Обновляем текст
    if (statusText) {
        const m = document.getElementById('scraptify-injected-marquee');
        if (m) m.innerText = statusText;
	}
    if (progressText) {
        const p = document.getElementById('scraptify-injected-progress');
        if (p) p.innerText = progressText;
	}
}

// --- Вспомогательная функция для вызова инъекции из background.js ---
async function updatePageOverlay(tabId, status, progress) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId },
            func: injectOverlayStatus,
            args: [status, progress]
		});
		} catch (e) {
        // Игнорируем ошибки, если вкладка закрылась или недоступна
        console.warn("Не удалось обновить оверлей на странице:", e);
	}
}


async function startMultiPageParse(tabId, scraperCode, resume = true) {
    console.log("🚀 startMultiPageParse запущен", { tabId, hasCode: !!scraperCode, resume });
    let hostname = '';
    let products = [];
    
    try {
        // 1. ПОЛУЧАЕМ СТАТУС ПОДПИСКИ
        const storageData = await chrome.storage.local.get(['isPremiumUser']);
        const isPremium = storageData.isPremiumUser === true;
        const FREE_LIMIT = 100;

        const tab = await chrome.tabs.get(tabId);
        hostname = new URL(tab.url).hostname.replace(/^www\./, ''); 
        console.log("🌐 Парсинг для хоста:", hostname, "Premium:", isPremium);
        
        let currentPageUrl = tab.url;
        if (resume) {
            const session = await getSession(hostname);
            if (session && session.products) {
                products = session.products;
                currentPageUrl = session.nextPageUrl || tab.url;
                console.log(`Продолжаем сессию. Найдено ${products.length} товаров. Следующий URL: ${currentPageUrl}`);
            }
        } else {
            console.log("Начинаем новую сессию, предыдущие данные будут проигнорированы.");
        }
        
        
        if (parsingState.isParsing) {
            return { success: false, error: "🚫 Парсинг уже запущен." };
        }
        
        resetParsingState();
        parsingState.isParsing = true;
        parsingState.currentTabId = tabId;
        parsingState.scraperCode = scraperCode;
        parsingState.hostname = hostname;
        parsingState.abortController = new AbortController();
        
        let page = Math.floor(products.length / 24) || 0; 
        
        await updatePageOverlay(tabId, 
            chrome.i18n.getMessage("overlayStarting"), 
            chrome.i18n.getMessage("overlayLoadedPrev", [String(products.length)])
        );
        
        let limitReached = false; // Флаг достижения лимита

        while (true) {
            if (parsingState.abortController.signal.aborted) {
                console.log("Цикл прерван в начале итерации.");
                break;
            }

            // --- ПРОВЕРКА ЛИМИТА ПЕРЕД НАЧАЛОМ СТРАНИЦЫ ---
            if (!isPremium && products.length >= FREE_LIMIT) {
                console.log(`🔒 Достигнут лимит Free версии (${FREE_LIMIT} товаров). Остановка.`);
                products = products.slice(0, FREE_LIMIT); // Обрезаем лишнее
                limitReached = true;
                break; // Выходим из цикла
            }
            
            page++;
            const statusMsg = chrome.i18n.getMessage("overlayParsingPage", [String(page)]);
            const progressMsg = chrome.i18n.getMessage("overlayCollectedStats", [String(products.length)]);
            
            chrome.runtime.sendMessage({
                action: "updateProgress",
                page,
                count: products.length 
            });
            await updatePageOverlay(tabId, statusMsg, progressMsg);
            
            const currentTab = await chrome.tabs.get(tabId);
            if (currentPageUrl !== currentTab.url) {
                await updatePageOverlay(tabId, 
                    chrome.i18n.getMessage("overlayNavigating", [String(page)]), 
                    progressMsg
                );
                
                await chrome.tabs.update(tabId, { url: currentPageUrl });
                await waitForPageLoad(tabId, currentPageUrl);
                
                await updatePageOverlay(tabId, statusMsg, progressMsg);
            }
            
            if (parsingState.abortController.signal.aborted) break;
            
            const result = await executeScraper(tabId, scraperCode);
            
            if (result && result.products) {
                const newProducts = result.products.filter(p => p.name && p.url);
                products.push(...newProducts);
                
                // --- ПРОВЕРКА ЛИМИТА ПОСЛЕ СБОРА ---
                if (!isPremium && products.length >= FREE_LIMIT) {
                    products = products.slice(0, FREE_LIMIT); // Обрезаем до ровно 100
                    parsingState.products = products;
                    parsingState.count = products.length;
                    limitReached = true;
                    
                    // Сохраняем и выходим
                    console.log("🔒 Лимит достигнут после сбора товаров.");
                    await saveSession(hostname, products, null); // null, чтобы не продолжать дальше
                    break; 
                }

                // Обновляем внутреннее состояние
                parsingState.products = products;
                parsingState.count = products.length;
                parsingState.page = page;
                
                await updatePageOverlay(tabId, 
                    chrome.i18n.getMessage("overlayExtracted", [String(newProducts.length), String(page)]), 
                    chrome.i18n.getMessage("overlayTotal", [String(products.length)])
                );
            }
            
            // ... (обработка abortController, nextPageSelector сохраняется как было) ...
             if (parsingState.abortController.signal.aborted) {
                console.log("Сигнал остановки получен. Финальное сохранение частичных данных...");
                await saveSession(hostname, products, null);
                
                await updatePageOverlay(tabId, 
                    chrome.i18n.getMessage("overlayStoppedUser"), 
                    chrome.i18n.getMessage("overlayFinalTotal", [String(products.length)])
                );
                break;
            }
            
            if (!result || !result.nextPageSelector) {
                console.log("Не найден селектор следующей страницы, завершаем.");
                await saveSession(hostname, products, null);
                break;
            }
            
            let nextUrl;
            if (result.nextPageSelector && (result.nextPageSelector.startsWith('http') || result.nextPageSelector.startsWith('//'))) {
                nextUrl = result.nextPageSelector;
            } else {
                nextUrl = await getNavLink(tabId, result.nextPageSelector);
            }
            
            await saveSession(hostname, products, nextUrl);
            
            if (!nextUrl) {
                console.log("Не удалось получить URL следующей страницы, завершаем.");
                await saveSession(hostname, products, null);
                break;
            }
            
            currentPageUrl = nextUrl;
        }
        
        const wasAborted = parsingState.abortController.signal.aborted;
        
        console.log(wasAborted ? `⏹️ Парсинг остановлен.` : `✅ Парсинг завершен.`);
        console.log(`Собрано ${products.length} товаров.`);
        
        parsingState.isParsing = false;
        parsingState.isComplete = true;
        parsingState.products = products;
        parsingState.total = products.length;
        
        // --- VISUAL: Финал ---
        let finalStatus;
        if (limitReached) {
            finalStatus = chrome.i18n.getMessage("freeLimit");
        } else {
            finalStatus = wasAborted 
            ? chrome.i18n.getMessage("overlayStatusStopped") 
            : chrome.i18n.getMessage("overlayStatusComplete");
        }
        
        await updatePageOverlay(tabId, 
            finalStatus, 
            chrome.i18n.getMessage("overlayDownloadReady", [String(products.length)])
        );
        
        // Отправляем сообщение в popup
        if (wasAborted) {
            chrome.runtime.sendMessage({ action: "parsingStopped", total: products.length });
        } else {
            // Если лимит достигнут, считаем это успешным завершением (но с лимитом)
            chrome.runtime.sendMessage({ action: "parsingComplete", total: products.length });
        }
        
    } catch (error) {
        // ... (обработка ошибок остается прежней) ...
        console.error("💥 Ошибка в startMultiPageParse:", error);
        parsingState.isParsing = false;
        parsingState.isComplete = true;
        parsingState.products = products;
        parsingState.total = products.length;
        
        await updatePageOverlay(tabId, chrome.i18n.getMessage("overlayError"), error.message);
        if(hostname) await saveSession(hostname, products, null);
        
        chrome.runtime.sendMessage({
            action: "parsingError",
            error: error.message,
            total: products.length
        });
    }
}


async function waitForPageLoad(tabId, expectedUrl) {
    return new Promise(resolve => {
        const interval = setInterval(async () => {
            try {
                const tab = await chrome.tabs.get(tabId);
                if (parsingState.abortController?.signal.aborted) {
					clearInterval(interval);
					resolve();
					return;
				}
                // Проверяем статус complete
                if (tab.status === 'complete') {
                    // Дополнительная проверка: URL должен примерно совпадать (игнорируем якоря)
                    // Иногда URL меняется не сразу, поэтому можно добавить небольшую задержку
                    if(tab.url.startsWith(expectedUrl.split('#')[0])) {
                        clearInterval(interval);
                        setTimeout(resolve, 1500); // Даем чуть больше времени на рендеринг JS
					}
				}
				} catch(e) {
                clearInterval(interval);
                resolve(); // Если вкладка закрыта, выходим
			}
		}, 500);
	});
}

async function executeScraper(tabId, code) {
    try {
        const injectionResults = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            world: 'MAIN', // Выполняем в контексте страницы
            func: (scraperCode) => {
                try {
                    // Создаем асинхронную функцию
                    const runScraper = new Function(`
                        ${scraperCode};
                        // Запускаем скрейпер
                        return scrapeProducts().then(result => {
						try {
						// !!! ГЛАВНОЕ ИСПРАВЛЕНИЕ !!!
						// Принудительно очищаем данные от "мусора" (DOM-узлов, функций),
						// превращая их в чистый JSON. Это гарантирует доставку в расширение.
						return JSON.parse(JSON.stringify(result));
						} catch (jsonError) {
						console.error("Ошибка сериализации данных:", jsonError);
						return { products: [], nextPageSelector: null };
						}
                        });
					`);
                    return runScraper();
					} catch (e) {
                    console.error("Ошибка запуска скрейпера:", e);
                    return { products: [], nextPageSelector: null };
				}
			},
            args: [code]
		});
		
        if (injectionResults && injectionResults[0]) {
            return injectionResults[0].result;
		}
        return null;
		} catch (e) {
        console.error("Ошибка executeScraper:", e);
        return null;
	}
}

async function getNavLink(tabId, selector) {
    const result = await chrome.scripting.executeScript({
        target: { tabId },
        func: (sel) => {
            const el = document.querySelector(sel);
            return el?.href ? new URL(el.href, location.href).href : null;
		},
        args: [selector]
	});
    return result[0]?.result;
}

function handleParseMessage(message, sender, sendResponse) {
    if (message.action === "stopParsing") {
        if (parsingState.isParsing && parsingState.abortController) {
            console.log("⏹️ Получена команда stopParsing.");
            
            parsingState.abortController.abort();
            
            if (parsingState.currentTabId) {
                console.log(`🚀 Отправка события 'stop-scraping' во вкладку ${parsingState.currentTabId}`);
                
                // --- VISUAL: Сообщаем на странице, что нажали стоп ---
                updatePageOverlay(parsingState.currentTabId, 
					chrome.i18n.getMessage("overlayStoppingWait"), 
					chrome.i18n.getMessage("overlaySaving")
				);
				
                chrome.scripting.executeScript({
                    target: { tabId: parsingState.currentTabId },
                    func: () => {
                        window.dispatchEvent(new CustomEvent('stop-scraping'));
					}
				}).catch(err => console.error("Не удалось отправить событие 'stop-scraping':", err));
			}
			
            sendResponse({success: true, message: "Сигнал остановки отправлен."});
		}
        return true;
	}
	
    if (message.action === "startMultiPageParse") {
        console.log("🟢 Обработка startMultiPageParse");
        (async () => {
            // Передаем флаг resume из сообщения
            await startMultiPageParse(message.tabId, message.scraperCode, message.resume);
		})();
        return true;
	}
	
    return false;
}

self.handleParseMessage = handleParseMessage;
self.startMultiPageParse = startMultiPageParse;