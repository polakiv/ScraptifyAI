// _modules/logger.js
// Можно использовать для централизованного лога
self.log = (msg, type = 'info') => {
    console[type](`[Logger] ${new Date().toISOString()} — ${msg}`);
};