// _modules/state-manager.js
// Управление состоянием парсинга

let parsingState = {
    isParsing: false,
    isComplete: false,
    page: 0,
    count: 0,
    total: 0,
    products: [],
    currentPage: 1,
    totalFound: 0,
    currentTabId: null,
    abortController: null,
    lastUrl: null,
    scraperCode: null,
    hostname: null
};

function resetParsingState() {
    if (parsingState.abortController) {
        parsingState.abortController.abort();
    }
    parsingState = { 
        isParsing: false,
        isComplete: false,
        page: 0,
        count: 0,
        total: 0,
        products: [],
        currentTabId: null,
        abortController: null,
        lastUrl: null,
        scraperCode: null,
        currentPage: 1,
        totalFound: 0,
        hostname: null
    };
}

// Экспортируем как глобальные функции/переменные
self.parsingState = parsingState;
self.resetParsingState = resetParsingState;

