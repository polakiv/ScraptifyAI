// modules/config.js

// Конечная точка для сохранения ЭКСПЕРИМЕНТАЛЬНОГО кода скрейпера
const API_ENDPOINT_SAVE_SCRAPER = 'https://nsk-sites.ru/save_scraper-finger.php';
// Конечная точка для "продвижения" экспериментального кода в продакшн
const API_ENDPOINT_PROMOTE_SCRAPER = 'https://nsk-sites.ru/save_scraper-finger-into-product.php';

// Конечная точка для получения скрейпера из продакшена
const API_ENDPOINT_GET_SCRAPER = 'https://nsk-sites.ru/get_scraper-finger.php';
// ---> ДОБАВЛЕНО: Конечная точка для получения ЭКСПЕРИМЕНТАЛЬНОГО скрейпера <---
const API_ENDPOINT_GET_SCRAPER_EXP = 'https://nsk-sites.ru/get_scraper-exp-finger.php';

// Конечная точка для прокси-сервера Gemini
const API_ENDPOINT_GEMINI_PROXY = 'http://144.31.71.68/ai.php';

const API_ENDPOINT_CHECK_SUB = 'https://nsk-sites.ru/scraptify/check_subscription.php';
 

// Делаем константы доступными для всех импортированных модулей
self.API_ENDPOINT_SAVE_SCRAPER = API_ENDPOINT_SAVE_SCRAPER;
self.API_ENDPOINT_PROMOTE_SCRAPER = API_ENDPOINT_PROMOTE_SCRAPER;
self.API_ENDPOINT_GET_SCRAPER = API_ENDPOINT_GET_SCRAPER;
self.API_ENDPOINT_GET_SCRAPER_EXP = API_ENDPOINT_GET_SCRAPER_EXP;  
self.API_ENDPOINT_GEMINI_PROXY = API_ENDPOINT_GEMINI_PROXY;

self.API_ENDPOINT_CHECK_SUB = API_ENDPOINT_CHECK_SUB;