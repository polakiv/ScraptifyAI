// =================================================================
// background.js - Главный сервисный воркер расширения
// ================================================================= 
 
// ---  Импорт всех необходимых модулей (БЕЗ config.js) ---
try {
    importScripts(
        'lib/xlsx.full.min.js',
        'modules/state-manager.js',
        'modules/config.js', //  
        'modules/db-manager.js',
        'modules/scraper-generator.js',
        'modules/multi-page-parser.js',
        'modules/excel-exporter.js',
        'modules/logger.js'
    );
} catch (e) {
    console.error("Критическая ошибка при первоначальном импорте скриптов:", e);
}/* 
try {
    importScripts(
        'modules/state-manager.js',
        'config.js',
        'modules/db-manager.js',
        'modules/scraper-generator.js',
        'modules/multi-page-parser.js',
        'modules/excel-exporter.js',
        'modules/logger.js'
    );
} catch (e) {
    // Эта ошибка будет видна только при самой первой установке, если какой-то файл отсутствует.
    console.error("Критическая ошибка при первоначальном импорте скриптов:", e);
} */


// --- 2. Инициализация при запуске расширения ---
// --- SIDE PANEL SETUP ---
// Настраиваем открытие панели при клике на иконку
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));
 
chrome.runtime.onStartup.addListener(() => {
    console.log("Расширение запущено.");
    initDB(); // Инициализируем IndexedDB
    cleanupOldSessions(); // Чистим старые сессии парсинга
});

chrome.runtime.onInstalled.addListener(() => {
    console.log("Расширение установлено или обновлено.");
    initDB();
});


// --- 3. Центральный обработчик сообщений ---
// Он принимает все сообщения от popup.js и других частей расширения
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	
	 // Задача: Исправить скрейпер с помощью ИИ
    if (message.action === "repairScraper") {
        console.log("🤖 Background: Получен запрос на ремонт скрейпера.");
        const { tabId, url, fingerprint, existingCode, userRequest } = message;

        (async () => {
            // Вызываем функцию из модуля scraper-generator.js
            const result = await repairScraperCode(tabId, url, fingerprint, existingCode, userRequest);
            sendResponse(result);
        })();
        
        return true; // Асинхронный ответ
    }
    // Сообщения от контент-скриптов или других вкладок игнорируются
    if (sender.tab) {
        return false;
    }

    // --- Делегирование задач модулям ---

    // Задача: Сгенерировать новый скрейпер
    if (handleGenerateMessage(message, sender, sendResponse)) {
        return true; // Возвращаем true, чтобы канал для sendResponse оставался открытым
    }

    // Задачи: Начать/остановить парсинг
    if (handleParseMessage(message, sender, sendResponse)) {
        return true;
    }

    // Задача: Экспортировать данные в Excel
    if (message.action === "downloadExcel") {
        handleExcelExport(message, sender, sendResponse);
        return true;
    }
    if (message.action === "promoteScraper") {
        const { fingerprint } = message;
        console.log(`[Background] Получена команда promoteScraper для отпечатка: ${fingerprint}`); // Логирование

        if (!fingerprint) {
            sendResponse({ success: false, error: "Fingerprint is missing" });
            return false;
        }

        fetch(API_ENDPOINT_PROMOTE_SCRAPER, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ layout_fingerprint: fingerprint })
        })
        .then(response => {
            // Проверяем, является ли ответ JSON перед парсингом
            const contentType = response.headers.get("content-type");
            if (response.ok && contentType && contentType.indexOf("application/json") !== -1) {
                return response.json();
            }
            // Если ответ не JSON или есть ошибка, получаем его как текст
            return response.text().then(text => {
                throw new Error(`Server returned non-JSON response or an error. Status: ${response.status}. Response: ${text}`);
            });
        })
        .then(data => {
            console.log("[Background] Успешный ответ от сервера:", data); // Логирование
            sendResponse(data); // Отправляем ответ от сервера как есть
        })
        .catch(error => {
            console.error("[Background] Ошибка при отправке скрейпера в продакшн:", error.message); // Логирование
            sendResponse({ success: false, error: error.message });
        });
        return true; // Указываем, что ответ будет асинхронным
    }
    // --- Обработка прямых запросов к background.js ---
// ---> ДОБАВЛЕНО: Получить ЭКСПЕРИМЕНТАЛЬНЫЙ скрейпер из удаленной БД <---
    if (message.action === "fetchScraperExpFromDB") {
        const { fingerprint } = message;
        if (!fingerprint) {
            sendResponse({ success: false, error: "Fingerprint is missing" });
            return false;
        }

        const fetchUrl = `${API_ENDPOINT_GET_SCRAPER_EXP}?fingerprint=${encodeURIComponent(fingerprint)}`;
        console.log("Запрос к удаленной БД за экспериментальным скрейпером:", fetchUrl);

        fetch(fetchUrl)
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => { throw new Error(err.error || "Network response was not ok") });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    sendResponse({ success: true, code: data.scraper_code });
                } else {
                    sendResponse({ success: false, error: data.error || "Scraper not found" });
                }
            })
            .catch(error => {
                console.error("Ошибка при запросе экспериментального скрейпера из БД:", error);
                sendResponse({ success: false, error: error.message });
            });
        return true; // Указываем, что ответ будет асинхронным
    }
    // Задача: Получить скрейпер из удаленной БД
    if (message.action === "fetchScraperFromDB") {
        const { hostname, fingerprint } = message;
        if (!hostname || !fingerprint) {
            sendResponse({ success: false, error: "Hostname or fingerprint is missing" });
            return false;
        }

        const fetchUrl = `${API_ENDPOINT_GET_SCRAPER}?hostname=${encodeURIComponent(hostname)}&fingerprint=${encodeURIComponent(fingerprint)}`;
        console.log("Запрос к удаленной БД:", fetchUrl);

        fetch(fetchUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Network response was not ok, status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    sendResponse({ success: true, code: data.scraper_code });
                } else {
                    sendResponse({ success: false, error: data.error || "Scraper not found" });
                }
            })
            .catch(error => {
                console.error("Ошибка при запросе скрейпера из БД:", error);
                sendResponse({ success: false, error: error.message });
            });
        return true; // Указываем, что ответ будет асинхронным
    }

    // Задача: Получить текущее состояние парсинга
    if (message.action === "getParsingState") {
        sendResponse(parsingState);
        return false;
    }

    // --- Управление сессиями в IndexedDB ---

    if (message.action === "getSession") {
        getSession(message.hostname).then(sendResponse);
        return true;
    }

    if (message.action === "deleteSession") {
        deleteSession(message.hostname).then(sendResponse);
        return true;
    }

    // Если ни один обработчик не сработал
    return false;
});