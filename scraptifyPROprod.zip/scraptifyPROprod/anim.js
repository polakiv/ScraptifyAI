// Import directly from the file path defined in your web_accessible_resources
import * as THREE from './lib/three.module.js';

// 1. SCENE SETUP
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x000000, 0.08); 

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(0, 1, 3);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);

// Append to body (or a specific container if you prefer)
document.body.appendChild(renderer.domElement);

// Ensure the canvas stays in the background if necessary via CSS, 
// or set style here:
renderer.domElement.style.position = 'fixed';
renderer.domElement.style.top = '0';
renderer.domElement.style.left = '0';
renderer.domElement.style.zIndex = '-1'; // Put behind your UI cards

// 2. GRID TEXTURE
function createGridTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#000000'; 
    ctx.fillRect(0, 0, 1024, 1024);
    
    ctx.strokeStyle = '#ff00ff'; 
    ctx.lineWidth = 2; 
    
    const step = 20; 
    ctx.beginPath();
    for (let i = 0; i <= 1024; i += step) {
        ctx.moveTo(i, 0); ctx.lineTo(i, 1024);
        ctx.moveTo(0, i); ctx.lineTo(1024, i);
    }
    ctx.stroke();

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.anisotropy = 8;
    
    return texture;
}

const gridTexture = createGridTexture();

// 3. CURVED PLANE
const geometry = new THREE.PlaneGeometry(40, 40, 80, 100);
const positionAttribute = geometry.attributes.position;
const bendStart = 3.5; 

for ( let i = 0; i < positionAttribute.count; i ++ ) {
    const y = positionAttribute.getY( i );
    if (y > bendStart) {
         const dist = y - bendStart;
         const zOffset = Math.pow(dist, 3) * 0.2; 
         positionAttribute.setZ(i, zOffset);
    }
}
geometry.computeVertexNormals();

const material = new THREE.MeshBasicMaterial({ 
    map: gridTexture,
    side: THREE.DoubleSide
});

const plane = new THREE.Mesh(geometry, material);
 plane.rotation.x = -Math.PI / 5; 
plane.position.z = -1; 
scene.add(plane);

// 4. ANIMATION
let speed = 0.001; 

function animate() {
    requestAnimationFrame(animate);
    gridTexture.offset.y -= speed;
    renderer.render(scene, camera);
}

// Resize handler
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();