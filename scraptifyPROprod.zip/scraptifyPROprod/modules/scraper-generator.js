// modules/scraper-generator.js
// --- ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ ДЛЯ TELEGRAM ---
async function sendTelegramNotification(actionType, siteUrl, htmlLength, userMessage = null) {
    // Токены удалены. Отправляем данные на ваш сервер.
    const apiUrl = self.API_ENDPOINT_TELEGRAM_PROXY; 
	
    const payload = {
        type: "log", // Тип сообщения для логов
        action: actionType,
        site: siteUrl,
        length: htmlLength,
        user_message: userMessage
    };
	
    try {
        await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
		});
    } catch (error) {
        console.error("Telegram Notification Error (Proxy):", error);
    }
}

// --- ФУНКЦИИ ДЛЯ ВИДЕО-ПРЕЛОАДЕРА (Внедряются на страницу) ---

function injectLoaderOverlay() {
    // Если уже есть - не создаем дубликат
    if (document.getElementById('scraptify-video-loader')) return;

    const overlay = document.createElement('div');
    overlay.id = 'scraptify-video-loader';
    // Стили для перекрытия всего экрана
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: black;
        z-index: 2147483647;  
        overflow: hidden;
    `;

    // 1. Создаем Canvas
    const canvas = document.createElement('canvas');
    canvas.id = 'matrixCanvas';
    canvas.style.display = 'block';
    
    // 2. Настройка контекста и размеров
    const ctx = canvas.getContext('2d');
    
    // Функция установки размеров
    const resizeCanvas = () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    };
    resizeCanvas();
    
    // 3. Набор символов
    const katakana = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const latin = '010101010101';
    const nums = '01';
    const alphabet = katakana + latin + nums;

    // 4. Параметры колонок
    const fontSize = 16;
    let columns = canvas.width / fontSize;

    const drops = [];
    for(let x = 0; x < columns; x++) {
        drops[x] = 1;
    }

    // 5. Функция рисования
    const draw = () => {
        // Полупрозрачный фон для следа
        ctx.fillStyle = 'rgba(0, 0, 0, 0.05)'; 
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#0F0'; // Зеленый цвет
        ctx.font = fontSize + 'px monospace';

        for(let i = 0; i < drops.length; i++) {
            const text = alphabet.charAt(Math.floor(Math.random() * alphabet.length));
            ctx.fillText(text, i * fontSize, drops[i] * fontSize);

            if(drops[i] * fontSize > canvas.height && Math.random() > 0.975){
                drops[i] = 0;
            }
            drops[i]++;
        }
    };

    // 6. Запуск анимации
    const intervalId = setInterval(draw, 30);
    
    // Сохраняем ID интервала в элемент, чтобы потом остановить
    overlay.dataset.intervalId = intervalId;

    // Обработка ресайза
    window.addEventListener('resize', resizeCanvas);

    // 7. Добавляем текст поверх матрицы
    const textContainer = document.createElement('div');
    textContainer.style.cssText = `
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        background: rgba(0, 0, 0, 0.8);
        padding: 40px;
        border: 2px solid #0F0;
        border-radius: 10px;
        box-shadow: 0 0 20px #0F0;
    `;

    const text = document.createElement('h2');
    text.innerText = chrome.i18n.getMessage("AiProcessing"); 
    text.style.cssText = `
        color: #0F0; 
        font-family: 'Courier New', monospace; 
        margin: 0;
        text-shadow: 0 0 5px #0F0;
        letter-spacing: 2px;
        white-space: pre-line;
    `;
    
    const subText = document.createElement('p');
    subText.innerText = chrome.i18n.getMessage("pleaseWait"); 
    subText.style.cssText = `
        color: #fff;
        font-family: sans-serif;
        margin-top: 15px;
        font-size: 14px;
        opacity: 0.8;
    `;

    textContainer.appendChild(text);
    textContainer.appendChild(subText);
    
    overlay.appendChild(canvas);
    overlay.appendChild(textContainer);
    document.body.appendChild(overlay);
}

function removeLoaderOverlay() {
    const overlay = document.getElementById('scraptify-video-loader');
    if (overlay) {
        // Останавливаем анимацию матрицы
        if (overlay.dataset.intervalId) {
            clearInterval(Number(overlay.dataset.intervalId));
        }
        
        // Плавное исчезновение
        overlay.style.transition = 'opacity 0.5s ease';
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 500);
    }
}

// --- ОСНОВНАЯ ФУНКЦИЯ СБОРА HTML (Внедряется на страницу) ---

async function getAndMinifyHtmlOnPage() {
    try {
        // --- БЛОК ПРОКРУТКИ ---
        console.log("Generator: Scrolling down to trigger lazy loading...");
        
        try {
            window.scrollTo({
                top: document.body.scrollHeight,
                behavior: 'smooth'
            });
        } catch (e) { console.warn("Scroll failed", e); }
        
        // Ждем 5 секунд (оптимально) пока прогрузится контент
        await new Promise(resolve => setTimeout(resolve, 5000));
        // --- КОНЕЦ БЛОКА ПРОКРУТКИ ---
        
        /**
         * Universal Advanced HTML Minify (v5.1 Fixed)
         */
        function advancedHtmlMinify(htmlString) {
            const TRUNCATION_THRESHOLD = 6; 
            
            const parser = new DOMParser();
            const doc = parser.parseFromString(htmlString, 'text/html');
            
            if (!doc || !doc.body) {
                return "<html><body>Error: Document Parse Failed</body></html>";
            }

            // Хелпер для определения пагинации
            function isPaginationOrEssential(el) {
                if (!el || !el.getAttribute) return false;
                if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE' || el.tagName === 'HEADER') return false; 
                
                const content = (el.textContent || "").toLowerCase();
                // Защита от зависания на огромных блоках текста
                if (content.length > 5000) return false; 

                const attrs = (el.className + " " + el.id + " " + el.getAttribute('aria-label') + " " + el.getAttribute('role')).toLowerCase();
                
                // 1. Проверка самого элемента
                const paginationKeywords = [
                    'pag', 'nav',
                    'load-more', 'show-more', 'next', 'prev', 'следующая', 'показать еще'
                ];
                
                if (paginationKeywords.some(kw => attrs.includes(kw))) return true;
                
                // 2. Проверка ВНУТРЕННЕГО содержимого
                if (el.querySelector) {
                    const hasInnerPagination = el.querySelector('nav, [class*="pagination" i], [class*="Pagination" i], [class*="pager" i], [id*="pagination" i], [class*="page-item" i]');
                    if (hasInnerPagination) return true;
                }
                
                // 3. Проверка по контенту (для кнопок)
                if (content.length < 100 && ( 
                    content.includes('next') || 
                    content.includes('далее') || 
                    content.includes('следующая') || 
                    content.includes('more') ||
                    content.includes('»') ||
                    content.includes('→')
                )) return true;
                
                return false;
            }
            
            // --- 1. Удаление комментариев ---
            const walker = document.createTreeWalker(doc, NodeFilter.SHOW_COMMENT);
            const comments = [];
            while (walker.nextNode()) comments.push(walker.currentNode);
            comments.forEach(c => c.remove());
            
            // --- 2. Умное удаление "мусора" ---
            const universalGarbageSelectors = [
                '[role="dialog"]', 
                '[aria-modal="true"]',
                '[x-data*="Modal"]', 
                '[id*="modal" i]', 
                '[class*="modal" i]',
                '[class*="pop" i]', 
                '[class*="captcha" i]',
                '[class*="menu-nav" i]',
                '[class*="m-menu" i]',
                '#jivo-iframe-container', 
                'jdiv', 'noframes', 'noindex', '[data-apiary="patch"]',
                '#thunderbit-crx-side-bar',
                'script', 'style', 'noscript', 'iframe', 'link', 'meta',
                'svg', 'symbol', 'defs', 'use', 'canvas', 'path', 'circle', 'rect', 'polygon', 'g',
                'header', 'footer', 'aside',  
                '[role="banner"]', '[role="contentinfo"]',
                '[class*="header" i]', '[id*="header" i]',
                '[class*="footer" i]', '[id*="footer" i]',
                '[class*="sidebar" i]', '[id*="sidebar" i]',
                '[class*="banner" i]', '[id*="banner" i]',
                '[class*="promo" i]', '[class*="adv" i]', '[class*="Adv" i]', '[class*="chat" i]', '[class*="widget" i]', '[id*="chat" i]', '[id*="widget" i]',
                '[class*="adv-" i]', '[id*="adv-" i]', '[id*="filters" i]', '[class*="filters" i]', '[class*="Filters" i]',
                '[class*="cookie" i]', '[id*="cookie" i]',
                '#scraptify-video-loader', '#scraptify-overlay-panel',
                'script[id="__NEXT_DATA__"]',    
                '.splide__track', 
                '.map-container', 
                '#map_new', 'template',
                '#popmechanic-snippet',            
                '#regions-list-links',             
                '[class*="SaleBanner"]',            
                '[class*="ProductsList_widget-on-top"]',  
                '#products-of-day',               
                '[class*="FloatActions"]',        
                '[class*="Notifications"]',       
                '[class*="ProductsList_list-controls"]', 
                '#scraptify-video-loader' 
            ];
            
            universalGarbageSelectors.forEach(selector => {
                try {
                    doc.body.querySelectorAll(selector).forEach(el => {
                        // Сначала проверяем, не является ли элемент пагинацией
                        if (isPaginationOrEssential(el)) return; 
                        
                        if (el.tagName !== 'BODY' && el.tagName !== 'MAIN') {
                            el.remove(); 
                        }
                    });
                } catch (e) {
                   // Игнорируем ошибки селекторов
                }
            });
            
            // --- 3. Очистка форм ---
            doc.querySelectorAll('form').forEach(form => {
                if (!form.querySelector('input, button, select') && !isPaginationOrEssential(form)) {
                    form.remove();
                }
            });
            
            // --- 4. Очистка атрибутов (ИСПРАВЛЕННАЯ ВЕРСИЯ) ---
            const allElements = doc.body.getElementsByTagName('*');
            for (let i = 0; i < allElements.length; i++) {
                const el = allElements[i];
                if (el.hasAttribute('style')) el.removeAttribute('style');
                
                // Превращаем NamedNodeMap в массив, чтобы можно было удалять атрибуты внутри цикла
                const attrs = Array.from(el.attributes); 
                
                for (const attr of attrs) {
                    const name = attr.name;
                    const lowerName = name.toLowerCase(); // ВАЖНО: определяем переменную здесь
                    
                    // Атрибуты, которые мы обрабатываем (ссылки), но оставляем
                    if (['href', 'src', 'action', 'data-url'].includes(lowerName)) {
                        // ЕСЛИ В ЗНАЧЕНИИ ЕСТЬ "=" (параметры)
                        if (attr.value.includes('=')) {
                            // Регулярка для сокращения длинных токенов
                            const newValue = attr.value.replace(/(=)([^&"'\s]{20,})/g, (match, eq, val) => { 
                                return eq + val.substring(0, 1) + '' + val.slice(-1);
                            });
                            
                            if (newValue !== attr.value) {
                                el.setAttribute(name, newValue);
                            }
                        }
                        continue; // Оставляем этот атрибут
                    }
                    
                    // !!! ЗДЕСЬ БЫЛА ОШИБКА !!!
                    // Атрибуты, которые мы просто оставляем без изменений
                    if (['href', 'src', 'srcset', 'class', 'id', 'value', 'action'].includes(lowerName)) {
                         continue; 
                    }
                    
                    if (lowerName.includes('pag') || lowerName.includes('url')) continue; 
                    
                    // Удаляем мусорные или очень длинные атрибуты
                    if (
                        lowerName.startsWith('_ng') ||
                        lowerName.startsWith('data-v-') ||
                        lowerName.startsWith('data-react') ||
                        lowerName.startsWith('data-apiary-widget') ||
                        lowerName.startsWith('on') || 
                        (attr.value.length > 100) 
                    ) {
                        el.removeAttribute(name);
                    }
                }
            }
            
            // Удаление пустых контейнеров
            for (let i = allElements.length - 1; i >= 0; i--) {
                const el = allElements[i]; 
                if (el.children.length === 0 && !el.textContent.trim()) {
                    el.remove();
                } 
            }
            
            // --- 5. Усечение списков (List Truncation) ---
            const potentialLists = doc.body.querySelectorAll('*');
            
            potentialLists.forEach(container => {
                if (['HTML', 'HEAD', 'BODY', 'TITLE'].includes(container.tagName)) return;
                if (isPaginationOrEssential(container)) return; 
                
                const children = Array.from(container.children);
                
                if (children.length > TRUNCATION_THRESHOLD) {
                    const typeMap = new Map();
                    
                    children.forEach(child => {
                        const firstClass = child.classList.length > 0 ? child.classList[0] : '';
                        const key = `${child.tagName}||${firstClass}`;
                        if (!typeMap.has(key)) typeMap.set(key, []);
                        typeMap.get(key).push(child);
                    });
                    
                    typeMap.forEach((elements, key) => {
                        if (elements.length > TRUNCATION_THRESHOLD) {
                            const keepStart = 3;
                            const keepEnd = 1; 
                            let removedCount = 0;
                            
                            for (let i = keepStart; i < elements.length - keepEnd; i++) {
                                const el = elements[i];
                                if (isPaginationOrEssential(el)) continue;
                                el.remove();
                                removedCount++;
                            }
                            
                            if (removedCount > 0) {
                                const mark = doc.createElement('div');
                                mark.setAttribute('data-ai-info', 'truncated');
                                mark.innerText = `[AI: Removed ${removedCount} items like <${key.split('||')[0]}>]`;
                                if (elements[keepStart - 1]) {
                                    elements[keepStart - 1].after(mark);
                                }
                            }
                        }
                    });
                }
            });
            
            // --- 6. Финальная сборка ---
            let headHtml = '<head>';
            const title = doc.querySelector('title');
            if (title) headHtml += title.outerHTML;
            headHtml += '</head>';
            
            let finalHtml = doc.body.innerHTML
            .replace(/[\r\n\t]+/g, ' ')
            .replace(/\s{2,}/g, ' ')
            .replace(/>\s+</g, '><')
            .trim();
            
            return `<html>${headHtml}<body>${finalHtml}</body></html>`;
        }
        
        // Получаем HTML безопасно
        const rawHtml = document.documentElement ? document.documentElement.outerHTML : document.body.outerHTML;
        
        if (!rawHtml) throw new Error("Document HTML is empty");

        return advancedHtmlMinify(rawHtml);

    } catch (err) {
        console.error("Critical error in getAndMinifyHtmlOnPage:", err);
        // Возвращаем текст ошибки, чтобы Background script не получил null
        return "<html><body>Error during minification: " + err.message + "</body></html>";
    }
}


// --- 1. ГЕНЕРАЦИЯ СКРЕЙПЕРА ---
async function generateScraperCode(tabId, pageUrl, fingerprintFromMessage) {
    // Видео больше не нужно
    // const videoUrl = chrome.runtime.getURL('assets/back.mp4');

    try {
        // 1. Показываем MATRIX прелоадер
        await chrome.scripting.executeScript({
            target: { tabId },
            func: injectLoaderOverlay,
            args: [] // Аргументы больше не нужны
        });

        console.log("Generator: Получаю и очищаю HTML на странице...");
        
        // 2. Скроллим и берем HTML (матрица висит поверх)
        const injectionResult = await chrome.scripting.executeScript({
            target: { tabId },
            func: getAndMinifyHtmlOnPage,
		});

        const htmlContent = injectionResult?.[0]?.result;
        if (!htmlContent) throw new Error("Не удалось получить и обработать HTML со страницы.");
		console.log(htmlContent);
		// --- NOTIFICATION START ---
        // Отправляем уведомление о начале генерации (Generate)
        sendTelegramNotification("Запущена генерация скрейпера (AI)", pageUrl, htmlContent.length);
        // --- NOTIFICATION END ---
        console.log("Generator: Отправляю очищенный HTML на прокси-сервер...");
        
        const apiUrl = self.API_ENDPOINT_GEMINI_PROXY; 
        const payload = { html_content: htmlContent };
		
        const apiResponse = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
		});
		
        if (!apiResponse.ok) {
            const errorText = await apiResponse.text();
             throw new Error(`Proxy Server error: ${apiResponse.status} — ${errorText}`);
		}
		
        const data = await apiResponse.json();
        const generatedCode = data?.candidates?.[0]?.content?.parts?.[0]?.text;
       
		if (!generatedCode) throw new Error(chrome.i18n.getMessage("errorAiEmptyResponse"));
		const cleanCode = generatedCode.replace(/^```[a-z]*\s*\n?|```\s*$/g, '').trim();
       	const hostname = new URL(pageUrl).hostname.replace(/^www\./, '');
        const storageKey = fingerprintFromMessage; 
        
        if (!storageKey) throw new Error(chrome.i18n.getMessage("fingerprintMissing"));

        await chrome.storage.local.set({ [storageKey]: cleanCode });
		console.log(`Скрейпер для ${hostname} сохранён.`);
        
        return { success: true, code: cleanCode, message: `Скрейпер сохранён.` };
		
	} catch (error) {
        console.error("Generator error:", error);
        return { success: false, error: error.message };
	} finally {
        // 3. Убираем прелоадер
        try {
            await chrome.scripting.executeScript({
                target: { tabId },
                func: removeLoaderOverlay
            });
        } catch (e) {
            console.warn("Could not remove overlay:", e);
        }
    }
}


function handleGenerateMessage(message, sender, sendResponse) {
    if (message.action === "generateScraperCode" && message.tabId && message.url && message.fingerprint) {
        (async () => {
            const result = await generateScraperCode(message.tabId, message.url, message.fingerprint);
            sendResponse(result);
		})();
        return true; 
	}
    return false;
}

// --- 2. РЕМОНТ СКРЕЙПЕРА (AI REPAIR) ---
async function repairScraperCode(tabId, pageUrl, fingerprint, existingCode, userRequest) {
    // Видео больше не нужно
    // const videoUrl = chrome.runtime.getURL('assets/back.mp4');

    try {
        // 1. Показываем MATRIX прелоадер
        await chrome.scripting.executeScript({
            target: { tabId },
            func: injectLoaderOverlay,
            args: []
        });

        console.log("Repair: 1. Получаю HTML страницы (со скроллом)...");
        
        // 2. Скроллим и получаем HTML
        const injectionResult = await chrome.scripting.executeScript({
            target: { tabId },
            func: getAndMinifyHtmlOnPage,
        });

        const htmlContent = injectionResult?.[0]?.result;
		
        console.log(htmlContent);
        if (!htmlContent) throw new Error("Не удалось получить HTML контекст.");

        console.log("Repair: 2. Формирую запрос к AI...");
 // --- NOTIFICATION START ---
        // Отправляем уведомление о начале ремонта (Repair)
        sendTelegramNotification("Repair Scraper (AI)", pageUrl, htmlContent.length, userRequest);
        // --- NOTIFICATION END ---
        const combinedPrompt = `
=== INSTRUCTIONS FOR AI ===
You are a JavaScript Expert specializing in web scraping.
TASK: Fix or Update the provided "Current Scraper Code" based on the "User Request" and the provided "HTML Structure".
RULES:
1. Return ONLY the JavaScript code for the function 'scrapeProducts'.
2. Do NOT allow any markdown formatting (no \`\`\`js).
3. Do NOT add explanations or comments outside the code.
4. The code must be valid and ready to execute.

=== CURRENT SCRAPER CODE ===
${existingCode}

=== USER REQUEST ===
"${userRequest}" 

=== HTML STRUCTURE (Context) ===
${htmlContent}
`;

console.log(combinedPrompt);
        const apiUrl = self.API_ENDPOINT_GEMINI_PROXY; 
        const payload = { html_content: combinedPrompt };
        console.log("Repair: 3. Отправляю запрос на прокси...");
        
        const apiResponse = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!apiResponse.ok) {
            const errorText = await apiResponse.text();
            throw new Error(`AI Server Error: ${apiResponse.status} - ${errorText}`);
        }

        const data = await apiResponse.json();
        
        let generatedCode = data?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!generatedCode) {
            if (data.text) generatedCode = data.text;
            else throw new Error("AI вернул пустой ответ.");
        }

        console.log("Repair: 4. Очистка и сохранение ответа...");

        const cleanCode = generatedCode
            .replace(/^```[a-z]*\s*/i, '')
            .replace(/\s*```$/, '')
            .trim();

        const storageKey = fingerprint;
        const hostname = new URL(pageUrl).hostname.replace(/^www\./, '');

        await chrome.storage.local.set({ [storageKey]: cleanCode });
        
        console.log(`✅ Скрейпер для ${hostname} успешно исправлен.`);
        
        return { success: true, code: cleanCode };

    } catch (error) {
        console.error("❌ Repair error:", error);
        return { success: false, error: error.message };
    } finally {
        // 3. Убираем прелоадер
        try {
            await chrome.scripting.executeScript({
                target: { tabId },
                func: removeLoaderOverlay
            });
        } catch (e) {
            console.warn("Could not remove overlay:", e);
        }
    }
}
 
self.repairScraperCode = repairScraperCode;
self.handleGenerateMessage = handleGenerateMessage;