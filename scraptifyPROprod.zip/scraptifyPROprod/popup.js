// popup.js
const API_ENDPOINT_CHECK_SUB = 'https://nsk-sites.ru/scraptify/check_subscription.php';
const REPAIR_COOLDOWN_MS = 24 * 60 * 60 * 1000; 

// --- ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ---
let currentTab = null; 
// Глобальные переменные состояния
let currentHostname;
let scraperCode = null;
let activeFingerprint = null;
let isPremiumUser = false;
let usedHostnames = [];
let hasSavedSession = false;

// ... (Функция injectOverlayStatus ) ...
function injectOverlayStatus(statusText, progressText) {
    let container = document.getElementById('scraptify-overlay-panel');
    if (!container) {
        container = document.createElement('div');
        container.id = 'scraptify-overlay-panel';
        container.style.cssText = `
		position: fixed !important; bottom: 0 !important; left: 0 !important; width: 100% !important;
		background: rgba(18, 18, 18, 0.95) !important; border-top: 3px solid #f000f0 !important;
		color: #fff !important; z-index: 2147483647 !important; padding: 10px 20px !important;
		box-sizing: border-box !important; font-family: sans-serif !important; display: flex !important;
		flex-direction: column !important; gap: 8px !important; pointer-events: none !important;
        `;
        container.innerHTML = `
		<div style="border: 1px solid #f000f0; background: #000; padding: 4px; border-radius: 4px;">
		<marquee id="scraptify-injected-marquee" scrollamount="12" style="color: #f000f0; font-size: 16px;">Initializing...</marquee>
		</div>
		<p id="scraptify-injected-progress" style="margin: 0; text-align: center; font-size: 14px;  color: #fff;">Waiting...</p>
        `;
        const target = document.body || document.documentElement;
        if (target) target.appendChild(container);
	}
    if (statusText) { const m = document.getElementById('scraptify-injected-marquee'); if (m) m.innerText = statusText; }
    if (progressText) { const p = document.getElementById('scraptify-injected-progress'); if (p) p.innerText = progressText; }
}

async function updateGlobalStatus(mainMessage, subMessage = "") {
    const scraperStatus = document.getElementById('scraper-status');
    if (scraperStatus) scraperStatus.textContent = mainMessage;
    // Оверлей обновляем только если currentTab актуален
    if (currentTab && currentTab.id) {
        try {
            await chrome.scripting.executeScript({
                target: { tabId: currentTab.id },
                func: injectOverlayStatus,
                args: [mainMessage, subMessage || "Scraptify AI System"]
			});
		} catch (e) { /* Игнорируем ошибки при переключении вкладок */ }
	}
}

// ... (Функция generateLayoutFingerprint БЕЗ ИЗМЕНЕНИЙ) ...
function generateLayoutFingerprint() {
    try {
        const allowedTags = ['html', 'header', 'body', 'nav', 'div', 'a', 'ul'];
        const excludedKeywords = ['adfox', 'top', 'fixed'];
        const getAbbreviation = (text) => {
            if (!text) return '';
            return text.split(/[-_]/).map(part => part.charAt(0)).join('');
        };
        const getElementSignature = (element) => {
            if (!element) return null;
            const fullTagName = element.tagName.toLowerCase();
            if (!allowedTags.includes(fullTagName)) return null;
            const shortTagName = fullTagName.charAt(0);
            const checkKeyword = (value) => !excludedKeywords.some(keyword => value.toLowerCase().includes(keyword));
            let idPart = null;
            if (element.id && !/\d/.test(element.id) && checkKeyword(element.id)) {
                const idAbbr = getAbbreviation(element.id);
                if (idAbbr) idPart = `id:${idAbbr}`;
            }
            let classPart = null;
            if (['html', 'body', 'header'].includes(fullTagName) && element.classList.length > 0) {
                const firstClass = element.classList[0];
                if (checkKeyword(firstClass)) {
                    const classAbbr = getAbbreviation(firstClass);
                    if (classAbbr) classPart = `c:${classAbbr}`;
                }
            }
            let dataPagePart = null;
            const dataPageValue = element.getAttribute('data-page');
            if (dataPageValue && checkKeyword(dataPageValue)) {
                const abbr = getAbbreviation(dataPageValue);
                if (abbr) dataPagePart = `d:${abbr}`;
            }
            let itemtypePart = null;
            const itemTypeUrl = element.getAttribute('itemtype');
            if (itemTypeUrl) {
                const itemTypeName = itemTypeUrl.substring(itemTypeUrl.lastIndexOf('/') + 1);
                if (itemTypeName) {
                    const abbr = getAbbreviation(itemTypeName);
                    if (abbr) itemtypePart = `i:${abbr}`;
                }
            }
            let itempropPart = null;
            const itempropValue = element.getAttribute('itemprop');
            if (itempropValue && checkKeyword(itempropValue)) {
                const abbr = getAbbreviation(itempropValue);
                if (abbr) itempropPart = `i:${abbr}`;
            }
            const signatureParts = [idPart, classPart, dataPagePart, itemtypePart, itempropPart].filter(Boolean).join(';');
            
            // Возвращаем объект с обеими версиями
            return signatureParts ? { short: `${shortTagName}[${signatureParts}]`, debug: `${fullTagName}[${signatureParts}]` } : null;
        };

        const coreElements = Array.from(document.querySelectorAll('html, body, header'));
        const elementsWithAttrs = Array.from(document.querySelectorAll('[id], [data-page], [itemscope], [itemtype], [itemprop]'));
        const uniqueCandidates = [...new Set([...coreElements, ...elementsWithAttrs])];
        
        const signatures = uniqueCandidates.map(getElementSignature).filter(Boolean).slice(0, 5);
        
        // Собираем "сырую" строку (как она есть до очистки)
        const structuralFingerprint = signatures.map(s => s.short).join('|');
        
        // Собираем ПОЛНУЮ читаемую строку (html вместо h, body вместо b)
        const debugFingerprint = signatures.map(s => s.debug).join('|');

        // Оригинальная логика очистки и обрезки (НЕ МЕНЯЕМ)
        let cleanedStructuralFingerprint = structuralFingerprint.replace(/[^a-zA-Z]/g, '').slice(0, 19);
        const fingerprint = [cleanedStructuralFingerprint, null].filter(Boolean).join('|'); 
		
        // === ВЫВОД В КОНСОЛЬ ===
        console.group("Fingerprint Debug Info");
        // 1. Полная расшифровка с именами тегов (html, body...)
        console.log("FULL (Debug):", debugFingerprint);
        // 2. Строка с сокращениями до того, как ее порезали regex'ом и slice'ом
        console.log("RAW (Uncut):", structuralFingerprint);
        // 3. То, что скрипт вернет в итоге
        console.log("FINAL (Result):", fingerprint);
        console.groupEnd();

        if (!fingerprint) return null;
        return fingerprint;
    } catch (e) { console.error("Fingerprinter Error:", e); return null; }
} 

// ... (Функция localizeUI ) ...
function localizeUI() {
    const setLocaleText = (elementId, messageKey) => {
        const element = document.getElementById(elementId);
        if (element) element.textContent = chrome.i18n.getMessage(messageKey);
	};
    setLocaleText('extDescription', 'extDescription');
    setLocaleText('scraper-status', 'statusChecking');
    setLocaleText('generateScraperBtn', 'btnGenerateScraper');
    setLocaleText('startFullParseBtn', 'btnStartParsing');
    setLocaleText('continueParseBtn', 'btnContinueParseBtn');
    setLocaleText('stopParsingBtn', 'btnStopParsing');
    setLocaleText('downloadExcelBtn', 'btnDownloadExcel');
    setLocaleText('sendMessageBtn', 'btnSendMessage');
    setLocaleText('subscription-status-text', 'subscriptionStatusLoading');
    setLocaleText('subscribeBtn', 'btnSubscribe');
    setLocaleText('feedbackTitle', 'feedbackTitle');
    setLocaleText('feedbackText', 'feedbackText');
    setLocaleText('feedbackWebsiteLabel', 'feedbackWebsiteLabel');
    setLocaleText('feedbackEmailLabel', 'feedbackEmailLabel');
    setLocaleText('feedbackTextLabel', 'feedbackTextLabel');
    setLocaleText('submitFeedbackBtn', 'btnSubmit');
    setLocaleText('cancelFeedbackBtn', 'btnCancel');
    setLocaleText('cancelFeedbackBtn2', 'btnCancel2');
    setLocaleText('step2', 'step2');
    setLocaleText('step1', 'step1');
    setLocaleText('receiveScraperExpBtn', 'btnGetScraperExp');
    setLocaleText('acceptBtn', 'btnPromoteScraper');
    setLocaleText('scrapeNotWork', 'aiRepairHelpTitle');
    setLocaleText('repairBtn', 'btnAiRepair'); 
    setLocaleText('placeAiRepairLimit', 'placeAiRepairLimit'); 
    setLocaleText('feedbackTitle', 'headerReportToAdmin'); 
	
    const repairText = document.getElementById('repairText');
    if (repairText) repairText.placeholder = chrome.i18n.getMessage('placeholderAiRepair');
    const userText = document.getElementById('userText');
    if (userText) userText.placeholder = chrome.i18n.getMessage('userText');
}

// --- ОСНОВНАЯ ЛОГИКА ---
document.addEventListener('DOMContentLoaded', () => {
    localizeUI();
    
    // Элементы UI
    const receiveScraperExpBtn = document.getElementById('receiveScraperExpBtn');
    const generateBtn = document.getElementById('generateScraperBtn');
    const parseBtn = document.getElementById('startFullParseBtn');
    const continueBtn = document.getElementById('continueParseBtn');
    const stopBtn = document.getElementById('stopParsingBtn');
    const downloadBtn = document.getElementById('downloadExcelBtn');
    const scraperStatus = document.getElementById('scraper-status');
    const progressStatus = document.getElementById('progress-status');
    const subscriptionStatusText = document.getElementById('subscription-status-text');
    const subscribeBtn = document.getElementById('subscribeBtn');
	
    const acceptBtn = document.getElementById('acceptBtn');
    const mainContent = document.getElementById('main-content');
    const feedbackFormContainer = document.getElementById('feedbackFormContainer');
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const websiteUrlInput = document.getElementById('websiteUrl');
    const userEmailInput = document.getElementById('userEmail'); 
	const userTextInput = document.getElementById('userText'); 
    const submitFeedbackBtn = document.getElementById('submitFeedbackBtn');
    const cancelFeedbackBtn = document.getElementById('cancelFeedbackBtn');
    const cancelFeedbackBtn2 = document.getElementById('cancelFeedbackBtn2');
    const feedbackStatus = document.getElementById('feedbackStatus');
    const repairBtn = document.getElementById('repairBtn');
    const repairText = document.getElementById('repairText');
	
    const allActionButtons = [receiveScraperExpBtn, generateBtn, parseBtn, continueBtn, stopBtn, downloadBtn, acceptBtn];
    const FREE_TIER_LIMIT = 3;
    const REPAIR_LIMIT = 3; 

    // --- ФУНКЦИИ ЛОГИКИ (перенесены внутрь, чтобы видеть переменные) ---

    // 1. Проверка подписки
    async function checkServerSubscription() {
        try {
            const response = await fetch(API_ENDPOINT_CHECK_SUB, { method: 'GET', credentials: 'include' }); 
            const data = await response.json();
            if (data && data.isPremium) {
                await chrome.storage.local.set({ 'isPremiumUser': true, 'trialDaysLeft': data.daysLeft });
                return true;
            } else {
                await chrome.storage.local.set({ 'isPremiumUser': false });
                return false;
            }
        } catch (e) {
            console.error("Ошибка проверки подписки:", e);
            return false;
        }
    }

    async function updateSubscriptionUI() {
        await checkServerSubscription();
        return new Promise(resolve => {
            chrome.storage.local.get(['isPremiumUser', 'usedHostnames', 'trialDaysLeft'], (data) => { 
                isPremiumUser = data.isPremiumUser || false;
                usedHostnames = data.usedHostnames || [];
                
                if (isPremiumUser) {
                    const daysLeft = data.trialDaysLeft;
                    let displayStatus = "";
                    if (daysLeft && daysLeft > 0 && daysLeft < 365) {
                        displayStatus = `${chrome.i18n.getMessage("subStatusActive")} <br><span style="font-size:12px; color:#f000f0;">${chrome.i18n.getMessage("subStatusTrialInfo", [String(daysLeft)])}</span>`;
                    } else {
                        const displayDays = (daysLeft !== undefined && daysLeft !== null) ? daysLeft : '∞';
                        displayStatus = chrome.i18n.getMessage("subStatusUnlimitedDays", [String(displayDays)]);
                    }
                    const extendLabel = chrome.i18n.getMessage("linkExtend");
                    subscriptionStatusText.innerHTML = `${displayStatus} <a href="https://nsk-sites.ru/scraptify/payment.php" target="_blank" style="color: #f000f0; text-decoration: underline; cursor: pointer; margin-left: 5px;">${extendLabel}</a>`;
                    subscriptionStatusText.style.color = "#4CAF50";
                    subscribeBtn.style.display = 'none';
                    generateBtn.disabled = false;
                    scraperStatus.textContent = "Ready to work";
                } else {
                    const uniqueUsedCount = new Set(usedHostnames).size;
                    subscriptionStatusText.textContent = chrome.i18n.getMessage("subStatusFreeTier", [uniqueUsedCount.toString(), FREE_TIER_LIMIT.toString()]);
                    subscribeBtn.style.display = 'block';
                    if (uniqueUsedCount >= FREE_TIER_LIMIT && !usedHostnames.includes(currentHostname)) {
                        generateBtn.disabled = true;
                        scraperStatus.innerHTML = `<span style="color: #ff0055; font-weight: bold;">LIMIT REACHED!</span><br>Register now!`;
                        subscribeBtn.textContent = chrome.i18n.getMessage("get14");
                        subscribeBtn.href = "https://nsk-sites.ru/scraptify/login.php?tab=register";
                        subscribeBtn.style.background = "linear-gradient(45deg, #ff0055, #ff5500)";
                    } else {
                        generateBtn.disabled = false;
                        subscribeBtn.textContent = chrome.i18n.getMessage("btnSubscribe");
                        subscribeBtn.href = "https://nsk-sites.ru/scraptify/payment.php";
                        subscribeBtn.style.background = "";
                    }
                }
                resolve();
            });
        });
    }

    // 2. Проверка сессии
    function checkSessionExists(hostname) {
        return new Promise(resolve => {
            chrome.runtime.sendMessage({ action: "getSession", hostname }, (response) => {
                hasSavedSession = response && response.products && response.products.length > 0;
                resolve(hasSavedSession);
            });
        });
    }

    // 3. Проверка Repair (Status)
    async function checkRepairStatus() {
        if (!currentHostname) return;
        const data = await chrome.storage.local.get(['repairLockouts', 'repairUsedHostnames', 'isPremiumUser']);
        const lockouts = data.repairLockouts || {};
        const repairUsedList = data.repairUsedHostnames || [];
        const isPremium = data.isPremiumUser;
        const lastUsed = lockouts[currentHostname];
        const isLimitReached = !isPremium && repairUsedList.length >= REPAIR_LIMIT && !repairUsedList.includes(currentHostname);

        if (lastUsed) {
            const now = Date.now();
            const diff = now - lastUsed;
            if (diff < REPAIR_COOLDOWN_MS) {
                const hoursLeft = Math.ceil((REPAIR_COOLDOWN_MS - diff) / (1000 * 60 * 60));
                repairBtn.disabled = true;
                repairText.disabled = true;
                repairBtn.textContent = chrome.i18n.getMessage('repairLimitWait', [String(hoursLeft)]); 
                repairBtn.style.background = "#555";
                return;
            }
        }
        if (isLimitReached) {
            repairBtn.textContent = "Limit Reached - Get Premium";
            repairBtn.style.background = "linear-gradient(45deg, #ff0055, #ff5500)";
            repairBtn.disabled = true;
        } else {
            if (!repairBtn.disabled) {
                repairBtn.textContent = chrome.i18n.getMessage('btnAiRepair') || "Seek help from AI";
                repairBtn.style.background = "";
            }
        }
    }

    // 4. Обновление состояния кнопок
    function updateUI(state) {
        if (state.isParsing) {
            generateBtn.disabled = true;
            parseBtn.disabled = true;
            acceptBtn.disabled = false;
            continueBtn.disabled = true;
            stopBtn.disabled = false;
            progressStatus.style.display = 'block';
        //  progressStatus.textContent = chrome.i18n.getMessage("progressParsingPage", [String(state.page), String(state.count)]);
		   progressStatus.textContent = chrome.i18n.getMessage("overlayCollectedStats", [String(state.count)]);
        } else {
            stopBtn.disabled = true;
            if (state.isComplete) {
                progressStatus.style.display = 'block';
                if (state.total > 0) {
                    progressStatus.textContent = chrome.i18n.getMessage("progressComplete", [String(state.total)]);
                    downloadBtn.style.display = 'block';
                } else {
                    progressStatus.textContent = chrome.i18n.getMessage("progressCompleteNotFound");
                    downloadBtn.style.display = 'none';
                }
            } else {
                // Скрываем прогресс бар, если ничего не происходит
                 if(!state.total) progressStatus.style.display = 'none';
            }
            
            const isLimitReached = !isPremiumUser && new Set(usedHostnames).size >= FREE_TIER_LIMIT && !usedHostnames.includes(currentHostname);
            generateBtn.disabled = !!scraperCode || isLimitReached || !currentTab?.url?.startsWith('http');

            if (scraperCode) {
                if (hasSavedSession) {
                    parseBtn.style.display = 'block';
                    continueBtn.style.display = 'block';
                    continueBtn.disabled = false;
                    parseBtn.disabled = false;
                } else {
                    parseBtn.style.display = 'block';
                    continueBtn.style.display = 'none';
                    parseBtn.disabled = false;
                    continueBtn.disabled = true;
                }
                acceptBtn.disabled = false;
            } else {
                parseBtn.disabled = true;
                continueBtn.disabled = true;
                acceptBtn.disabled = true;
            }
        }
        updateButtonHighlight(state);
    }
    
    function updateButtonHighlight(state) {
        allActionButtons.forEach(btn => btn.classList.remove('blinking-active'));
        if (state.isParsing) {
            stopBtn.classList.add('blinking-active');
        } else if (state.isComplete && state.total > 0) {
            downloadBtn.classList.add('blinking-active');
        } else if (scraperCode) {
            if (hasSavedSession) {
                continueBtn.classList.add('blinking-active');
            } else {
                parseBtn.classList.add('blinking-active');
            }
        } else if (!generateBtn.disabled && currentTab?.url?.startsWith('http')) {
            generateBtn.classList.add('blinking-active');
        }
    }

    function updateUIState() {
        chrome.runtime.sendMessage({ action: "getParsingState" }, (response) => {
            updateUI(response || { isParsing: false, isComplete: false, total: 0 });
        });
    }

    // --- ГЛАВНАЯ ФУНКЦИЯ ИНИЦИАЛИЗАЦИИ ДЛЯ ТЕКУЩЕЙ ВКЛАДКИ ---
    async function initializeForCurrentTab() {
        // Сброс UI перед загрузкой
        scraperCode = null;
        activeFingerprint = null;
        currentHostname = null;
        hasSavedSession = false;
        scraperStatus.textContent = "Checking...";
        generateBtn.disabled = true;
        parseBtn.disabled = true;
        sendMessageBtn.style.display = 'block';
        downloadBtn.style.display = 'none';
        progressStatus.style.display = 'none';

        // Получаем активную вкладку
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        currentTab = tabs[0];

        if (!currentTab?.url || !currentTab.url.startsWith('http')) {
            updateGlobalStatus(chrome.i18n.getMessage("errorOnlyOnWebpages") || "Open a website", "System Idle");
            updateUI({ isParsing: false, isComplete: false, total: 0 });
            return;
        }

        currentHostname = new URL(currentTab.url).hostname.replace(/^www\./, '');
        
        // Запускаем параллельные проверки
        await Promise.all([
            updateSubscriptionUI(),
            checkSessionExists(currentHostname),
            checkRepairStatus()
        ]);

        try {
            const injectionResults = await chrome.scripting.executeScript({
                target: { tabId: currentTab.id },
                func: generateLayoutFingerprint
            });
            activeFingerprint = injectionResults[0]?.result;

            if (!activeFingerprint) {
                updateGlobalStatus("Structure not detected.", "Error");
                updateUI({ isParsing: false, isComplete: false, total: 0 });
                return;
            }

            console.log(`Fingerprint: ${activeFingerprint}`);
            const storageKey = activeFingerprint;
            const data = await chrome.storage.local.get([storageKey]);

            if (data[storageKey]) {
                scraperCode = data[storageKey]; 
				updateGlobalStatus(chrome.i18n.getMessage("statusScraperReady"), chrome.i18n.getMessage("labelReady"));
                sendMessageBtn.style.display = 'block';
                updateUIState();
            } else {
                updateGlobalStatus(chrome.i18n.getMessage("statusFindingInDB"), "Fetching...");
                chrome.runtime.sendMessage(
                    { action: "fetchScraperFromDB", hostname: currentHostname, fingerprint: activeFingerprint },
                    (response) => {
                        if (response && response.success) {
                            scraperCode = response.code;
                            chrome.storage.local.set({ [storageKey]: scraperCode });
							updateGlobalStatus(chrome.i18n.getMessage("statusLoadedFromDB", [currentHostname]), chrome.i18n.getMessage("labelLoaded"));
							sendMessageBtn.style.display = 'block'; 
                        } else {
                            updateGlobalStatus(chrome.i18n.getMessage("statusNotCreated", [currentHostname]), chrome.i18n.getMessage("labelNoScraperFound"));
							sendMessageBtn.style.display = 'block'; 
                        }
                        updateUIState();
                    }
                );
            }
        } catch (e) {
            console.error("Init Error:", e);
            updateGlobalStatus("Access Error", "Restricted Page");
            updateUI({ isParsing: false, isComplete: false, total: 0 });
        }
    }

    // --- СЛУШАТЕЛИ СОБЫТИЙ БРАУЗЕРА (ДЛЯ SIDE PANEL) ---
    
    // 1. При переключении вкладок
    chrome.tabs.onActivated.addListener(async (activeInfo) => {
       // await initializeForCurrentTab();
		 window.close();
    });

    // 2. При обновлении страницы (загрузка URL)
    chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
        if (tab.active && changeInfo.status === 'complete') {
            await initializeForCurrentTab();
        }
    });

    // --- ОБРАБОТЧИКИ КНОПОК (Logics remain largely the same) ---
    
    repairBtn.addEventListener('click', async (e) => {
        const storageData = await chrome.storage.local.get(['isPremiumUser', 'repairUsedHostnames']);
        const isPremium = storageData.isPremiumUser;
        const repairUsedList = storageData.repairUsedHostnames || [];

        if (!isPremium && !repairUsedList.includes(currentHostname) && repairUsedList.length >= REPAIR_LIMIT) {
			e.preventDefault();
			updateGlobalStatus(`Limit Reached.`, "Premium Required");
			window.open("https://nsk-sites.ru/scraptify/payment.php", "_blank");
			return; 
		}

        const userPrompt = repairText.value.trim();
        if (!scraperCode || !activeFingerprint || !userPrompt) {
            updateGlobalStatus("Missing info for AI repair.", "Error");
            return;
        }

        chrome.storage.local.get(['repairLockouts'], (result) => {
            const lockouts = result.repairLockouts || {};
            lockouts[currentHostname] = Date.now();
            chrome.storage.local.set({ repairLockouts: lockouts }, checkRepairStatus);
        });

        repairBtn.disabled = true;
        repairText.disabled = true;
        updateGlobalStatus("AI Analyzing...", "Repairing");
        
        chrome.runtime.sendMessage({
            action: "repairScraper",
            tabId: currentTab.id,
            url: currentTab.url,
            fingerprint: activeFingerprint,
            existingCode: scraperCode,
            userRequest: userPrompt
        }, (response) => {
            checkRepairStatus();
            if (response && response.success) {
                scraperCode = response.code;
                const storageKey = activeFingerprint;
                chrome.storage.local.set({ [storageKey]: scraperCode }); // Сохраняем исправленный код!
                
                updateGlobalStatus(chrome.i18n.getMessage("statusFixedByAI"), chrome.i18n.getMessage("labelSuccess"));
                repairText.value = "";
                
                chrome.storage.local.get(['repairUsedHostnames', 'isPremiumUser'], (newData) => {
                    const currentList = newData.repairUsedHostnames || [];
                    if (!newData.isPremiumUser && !currentList.includes(currentHostname)) {
                        currentList.push(currentHostname);
                        chrome.storage.local.set({ repairUsedHostnames: currentList });
                    }
                });
                updateUIState();
            } else {
                updateGlobalStatus("AI Failed: " + (response?.error || "Unknown"), "Error");
            }
            repairBtn.disabled = false;
            repairText.disabled = false;
        });
    });

    receiveScraperExpBtn.addEventListener('click', () => {
        if (!activeFingerprint) return;
        receiveScraperExpBtn.disabled = true;
        chrome.runtime.sendMessage(
            { action: "fetchScraperExpFromDB", fingerprint: activeFingerprint },
            (response) => {
                if (response && response.success) {
                    scraperCode = response.code;
                    chrome.storage.local.set({ [activeFingerprint]: scraperCode });
                    updateGlobalStatus('Experimental Loaded!', "Exp Mode");
                    sendMessageBtn.style.display = 'block';
                    updateUIState();
                } else {
                    updateGlobalStatus('Not found.', "Error");
                }
                receiveScraperExpBtn.disabled = false;
            }
        );
    });

    generateBtn.addEventListener('click', () => {
        if (!activeFingerprint) return;
        updateGlobalStatus(chrome.i18n.getMessage("statusGenerating"), "AI Working...");
        generateBtn.disabled = true;
        updateButtonHighlight({ isParsing: false });

        chrome.runtime.sendMessage({ action: "generateScraperCode", tabId: currentTab.id, url: currentTab.url, fingerprint: activeFingerprint }, (response) => {
            if (response && response.success) {
                scraperCode = response.code;
                updateGlobalStatus(chrome.i18n.getMessage("statusScraperGenerated"), chrome.i18n.getMessage("labelSuccess"));
                sendMessageBtn.style.display = 'block';
                if (!isPremiumUser && !usedHostnames.includes(currentHostname)) {
                    usedHostnames.push(currentHostname);
                    chrome.storage.local.set({ 'usedHostnames': usedHostnames }, () => {
                         updateSubscriptionUI().then(() => updateUIState());
                    });
                } else {
                    updateUIState();
                }
            } else {
                updateGlobalStatus("Generation Failed", "Error");
                updateUIState();
            }
        });
    });

    parseBtn.addEventListener('click', () => {
        if (!scraperCode) return;
        chrome.runtime.sendMessage({ action: "deleteSession", hostname: currentHostname }, () => {
            hasSavedSession = false;
            updateUI({ isParsing: true, page: 1, count: 0, total: 0 });
            chrome.runtime.sendMessage({ action: "startMultiPageParse", tabId: currentTab.id, scraperCode: scraperCode, resume: false });
        });
    });

    continueBtn.addEventListener('click', () => {
        if (!scraperCode) return;
        updateUI({ isParsing: true, page: 1, count: 0, total: 0 });
        chrome.runtime.sendMessage({ action: "startMultiPageParse", tabId: currentTab.id, scraperCode: scraperCode, resume: true });
    });

    stopBtn.addEventListener('click', () => {
        stopBtn.disabled = true;
        chrome.runtime.sendMessage({ action: "stopParsing" });
    });

    downloadBtn.addEventListener('click', () => {
        if (!scraperCode && !hasSavedSession) return;
        chrome.runtime.sendMessage({
            action: "downloadExcel",
            url: currentTab.url,
            fingerprint: activeFingerprint,
            scraperCode: scraperCode
        });
    });
    
    acceptBtn.addEventListener('click', () => {
        if (!activeFingerprint) return;
        acceptBtn.disabled = true;
        chrome.runtime.sendMessage({ action: "promoteScraper", fingerprint: activeFingerprint }, (response) => {
             if (response && response.success) progressStatus.textContent = 'Sent to production!';
             else progressStatus.textContent = 'Error sending.';
             acceptBtn.disabled = false;
        });
    });

    // Обработка сообщений от background
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (sender.tab) return;
        if (message.action === "updateProgress") {
            updateUI({ isParsing: true, isComplete: false, page: message.page, count: message.count, total: 0 });
        } else if (message.action === "parsingComplete" || message.action === "parsingStopped") {
            checkSessionExists(currentHostname).then(() => {
                updateUI({ isParsing: false, isComplete: true, total: message.total });
            });
        } else if (message.action === "parsingError") {
            progressStatus.textContent = `Error: ${message.error}`;
            updateUI({ isParsing: false, isComplete: true, total: 0 });
        } else if (message.action === 'subscriptionStatusChanged') {
            updateSubscriptionUI().then(updateUIState);
        }
    });
    
    // UI Feedback Listeners
    sendMessageBtn.addEventListener('click', () => {
        mainContent.style.display = 'none';
        feedbackFormContainer.style.display = 'block';
        websiteUrlInput.value = currentTab.url;
        window.scrollTo(0, 0);
    });
    const hideFeedback = () => { feedbackFormContainer.style.display = 'none'; mainContent.style.display = 'block'; };
    cancelFeedbackBtn.addEventListener('click', hideFeedback);
    cancelFeedbackBtn2.addEventListener('click', hideFeedback);
    
    // Telegram Feedback
   function escapeMarkdown(text) { return text ? String(text).replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&') : ''; }
    
    submitFeedbackBtn.addEventListener('click', () => {
        const siteUrl = websiteUrlInput.value;
        const userEmail = userEmailInput.value || "Not provided";
        const userMessage = userTextInput.value || 'No message';
        
        feedbackStatus.textContent = chrome.i18n.getMessage("feedbackSending") || "Sending...";
        submitFeedbackBtn.disabled = true;
        
        // Формируем данные для отправки на ваш сервер
        const payload = {
            type: "feedback",
            site: siteUrl,
            email: userEmail,
            message: userMessage
        };
        
        // Отправляем на ВАШ сервер (proxy), а не напрямую в Telegram
        fetch(API_ENDPOINT_TELEGRAM_PROXY, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(r => r.json())
        .then(d => {
             if (d.success) {
                 feedbackStatus.textContent = chrome.i18n.getMessage("feedbackSuccess") || "Sent!";
                 setTimeout(() => { hideFeedback(); submitFeedbackBtn.disabled = false; }, 2000);
             } else {
                 throw new Error(d.error || "Server error");
             }
        })
        .catch(e => {
            console.error("Feedback error:", e);
            feedbackStatus.textContent = "Error sending message";
            submitFeedbackBtn.disabled = false;
        });
    });
 
subscribeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const url = subscribeBtn.getAttribute('href');
        if (url) {
            chrome.windows.create({ 
                url: url, 
                type: 'popup', // Окно без рамок браузера
                width: 800,    // Ширина (по желанию)
                height: 600,   // Высота (по желанию)
                focused: true
            });
        }
    });

    // --- ЗАПУСК ---
    // Инициализируем при первом открытии
    initializeForCurrentTab();
});