// modules/db-manager.js

const DB_NAME = 'ScrapingDB';
const DB_VERSION = 1;
const STORE_NAME = 'parsingSessions';
let db;

// Инициализация базы данных
function initDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            // Создаем хранилище объектов для сессий
            // Ключом будет hostname сайта
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                const store = db.createObjectStore(STORE_NAME, { keyPath: 'hostname' });
                // Индекс для поиска по дате, чтобы удалять старые записи
                store.createIndex('timestamp', 'timestamp', { unique: false });
            }
        };

        request.onsuccess = (event) => {
            db = event.target.result;
            console.log('✅ База данных IndexedDB успешно открыта.');
            resolve(db);
        };

        request.onerror = (event) => {
            console.error('❌ Ошибка открытия IndexedDB:', event.target.errorCode);
            reject(event.target.errorCode);
        };
    });
}

// Сохранение или обновление сессии
async function saveSession(hostname, products, nextPageUrl = null) {
    if (!db) await initDB();
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const session = {
        hostname: hostname,
        products: products,
        timestamp: new Date().getTime(),
        nextPageUrl: nextPageUrl // Сохраняем URL для возобновления
    };
    store.put(session);
    return transaction.complete;
}

// Получение сессии по hostname
async function getSession(hostname) {
    if (!db) await initDB();
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(hostname);
    return new Promise((resolve) => {
        request.onsuccess = () => {
            resolve(request.result);
        };
         request.onerror = () => {
            resolve(null);
        };
    });
}

// Удаление сессии по hostname
async function deleteSession(hostname) {
    if (!db) await initDB();
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.delete(hostname);
    return new Promise((resolve, reject) => {
        request.onsuccess = () => {
            console.log(`🧹 Сессия для ${hostname} удалена.`);
            resolve({success: true});
        };
        request.onerror = (event) => {
            console.error(`❌ Ошибка удаления сессии для ${hostname}:`, event.target.error);
            reject(event.target.error);
        };
    });
}


// Удаление старых сессий (TTL - Time To Live)
async function cleanupOldSessions() {
    if (!db) await initDB();
    const twoMonthsAgo = new Date().getTime() - (60 * 24 * 60 * 60 * 1000); // 60 дней в мс
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const index = store.index('timestamp');

    // Открываем курсор по индексу времени, чтобы перебрать записи старше X
    index.openCursor(IDBKeyRange.upperBound(twoMonthsAgo)).onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
            console.log(`🧹 Удаление старой сессии для ${cursor.value.hostname}`);
            store.delete(cursor.primaryKey);
            cursor.continue();
        }
    };
    return transaction.complete;
}
 
// Делаем функции доступными в глобальной области видимости Service Worker
self.initDB = initDB;
self.getSession = getSession;
self.deleteSession = deleteSession;
self.cleanupOldSessions = cleanupOldSessions;